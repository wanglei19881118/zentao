UPDATE `zt_grouppriv` SET `method`='productSummary' WHERE `method`='productInfo' AND `module`='report';
UPDATE `zt_grouppriv` SET `method`='bugCreate' WHERE `method`='bugSummary' AND `module`='report';
