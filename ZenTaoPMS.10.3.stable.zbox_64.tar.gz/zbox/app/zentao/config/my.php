<?php
$config->installed       = true;
$config->debug           = true;
//$config->requestType     = 'PATH_INFO';
$config->requestType     = 'GET';
$config->db->host        = '192.9.99.92';
$config->db->port        = '3306';
$config->db->name        = 'zentao';
$config->db->user        = 'root';
$config->db->password    = '123';
$config->db->prefix      = 'zt_';
$config->webRoot         = getWebRoot();
$config->default->lang   = 'zh-cn';
$config->mysqldump       = '/opt/lampp/bin/mysqldump';